#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>

//the following are UBUNTU/LINUX, and MacOS ONLY terminal color codes.
#define RESET		"\033[0m"
#define BLACK		"\033[30m"				// Black
#define RED			"\033[31m"				// Red
#define GREEN		"\033[32m"				// Green
#define YELLOW		"\033[33m"				// Yellow
#define BLUE		"\033[34m"				// Blue
#define MAGENTA		"\033[35m"				// Magenta
#define CYAN		"\033[36m"				// Cyan
#define WHITE		"\033[37m"				// White
#define BOLDBLACK   "\033[1m\033[30m"		// Bold Black
#define BOLDRED     "\033[1m\033[31m"		// Bold Red
#define BOLDGREEN   "\033[1m\033[32m"		// Bold Green
#define BOLDYELLOW  "\033[1m\033[33m"		// Bold Yellow
#define BOLDBLUE    "\033[1m\033[34m"		// Bold Blue 
#define BOLDMAGENTA "\033[1m\033[35m"		// Bold Magenta
#define BOLDCYAN    "\033[1m\033[36m"		// Bold Cyan 
#define BOLDWHITE   "\033[1m\033[37m"		// Bold White 

class Logger
{
	static bool verbose;
	static bool verboseIntoFile;
	static std::string filename;
	static std::ofstream fileStream;

public:
	static void init(const std::string& _filename, bool _verbose, bool _verboseToFile)
	{
		filename = _filename;
		verbose = _verbose;
		verboseIntoFile = _verboseToFile;

		if (verboseIntoFile)
		{
			//std::remove(filename.c_str());
			fileStream = std::ofstream(filename, std::ofstream::out);
		}
	}
		
	static void setVerbose(bool _verbose)
	{
		verbose = _verbose;
	}

	static void close()
	{
		if (verboseIntoFile)
		{
			fileStream.close();
		}
	}

	template <typename T>
	static void log(T t)
	{
		if (verbose)
		{
			std::cout << t;
		}
		if (verboseIntoFile)
		{
			fileStream << t;
		}
	}

	// recursive variadic function with beautiful templates
	template<typename T, typename... Args>
	static void log(T t, Args... args)
	{
		if (verbose)
		{
			std::cout << t;
		}
		if (verboseIntoFile)
		{
			fileStream << t;
		}

		log(args...);
	}
};