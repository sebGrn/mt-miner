#pragma once
#include <vector>
#include <algorithm>
#include <cassert>
#include <memory>
#include <bitset>

#include "utils.h"
#include "SparseBitset.h"

// 32768	// dualmatching30 --> OK, 10 sec
// 65536	// dualmatching32 --> OK, 48 sec
// 131072	// dualmatching34 --> OK, 444 sec
// 262144	// dualmatching36 --> PAS OK, 5 min, 47Go memory
// 524288	// dualmatching38
#define BITSET_SIZE 524288
typedef std::bitset<BITSET_SIZE> StaticBitset;

class Item
{
	// Class Itemset has access to all private members of an item
	friend class Itemset;

private:
	unsigned int attributeIndex;
	std::unique_ptr<StaticBitset> staticBitset;
	
	// true if this item is a clone
	bool isClone;
	
	// contains a list of clone for this item (same bitset)
	std::vector<std::shared_ptr<Item>> clones;

public:
	Item(int index, unsigned int bitsetSize)
	{
		this->staticBitset = std::make_unique<StaticBitset>();
		this->attributeIndex = index;
		this->isClone = false;
	}

	~Item()
	{
		clones.clear();
		staticBitset.reset();
	}

	void set(unsigned int i, bool value);
	bool get(unsigned int) const;
	unsigned int count() const;
	void addClone(const std::shared_ptr<Item>& clone);
	void setClone();
	unsigned int getAttributeIndex() const;
	bool isAnOriginal() const;
	unsigned int getCloneCount() const;
	std::shared_ptr<Item> getClone(unsigned int i) const;
	void resetClonedAttributesIndexes();
	bool isAClone() const;

	bool operator==(const Item& other);	
	//StaticBitset operator|(const StaticBitset& other);
	//StaticBitset operator&(const StaticBitset& other);
};

inline unsigned int Item::getAttributeIndex() const
{
	return this->attributeIndex;
}

inline void Item::set(unsigned int i, bool value)
{
	this->staticBitset->set(i, value);
}

inline bool Item::get(unsigned int i) const
{
	return this->staticBitset->test(i);
}

inline unsigned int Item::count() const
{
	return this->staticBitset->count();
}

inline void Item::addClone(const std::shared_ptr<Item>& clone)
{
	this->clones.push_back(clone);
}

inline void Item::setClone()
{
	this->isClone = true;
}

inline bool Item::isAnOriginal() const
{
	return !this->clones.empty();
}

inline void Item::resetClonedAttributesIndexes()
{
	this->clones.clear();
}

inline unsigned int Item::getCloneCount() const
{
	return static_cast<unsigned int>(this->clones.size());
}

inline std::shared_ptr<Item> Item::getClone(unsigned int i) const
{
	assert(i < this->clones.size());
	return this->clones[i];
}

inline bool Item::isAClone() const
{
	return this->isClone;
}

inline bool Item::operator==(const Item& other)
{
	if(other.attributeIndex == this->attributeIndex)
		return true;
	return (*other.staticBitset) == (*this->staticBitset);
}

//inline StaticBitset Item::operator|(const StaticBitset& other)
//{
//	return *this->staticBitset.get() | other;
//}
//
//inline StaticBitset Item::operator&(const StaticBitset& other)
//{
//	return *this->staticBitset.get() & other;
//}